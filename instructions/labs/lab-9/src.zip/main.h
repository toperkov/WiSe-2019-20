#ifndef main_h
#define main_h

// Payload that child sends to the parent
struct SensorData
{
    float temp;
    uint16_t lightLevel;
};

typedef enum
{
    READ_SERIAL,
    READ_SENSORS,
    RADIO_TX,
    SLEEP,
    NUM_STATES
} StateType;

#endif